# Conduce de Salida 3.6.2

CAMBIOS EXCLUSIVOS
1. Historial SQLite permanente de cada conduce cuyo PDF fue guardado. Sin caducidad. Consultas por fecha, persona, localidad y otros campos incluyendo materiales. Recuperación editable. Importación de historial temporal previo cuando permanece guardado.
2. Solo los colores de la interfaz de captura e historial: verde, azul y gris claro. El papel/plantilla PDF, campos, flujo Outlook y protección SafeArea son idénticos.

LIMITACIONES: la base SQLite local se borra al desinstalar la aplicación o borrar datos. La actualización APK debe tener la misma firma para conservar registros. NO desinstales sin respaldo. Solo se muestran hasta 200 coincidencias recientes por consulta, aunque la base conserva todos los registros.
