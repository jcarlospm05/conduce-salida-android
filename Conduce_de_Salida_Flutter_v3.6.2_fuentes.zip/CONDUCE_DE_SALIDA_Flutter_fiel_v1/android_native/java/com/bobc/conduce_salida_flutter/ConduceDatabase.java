package com.bobc.conduce_salida_flutter;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import org.json.JSONArray;
import org.json.JSONObject;
import java.util.Locale;
import java.util.UUID;

/** Historial permanente, privado y consultable. No se borran registros por fecha. */
public final class ConduceDatabase extends SQLiteOpenHelper {
    private static final String DB_NAME = "conduce_salida_historial.db";
    private static final String TABLE = "conduces";
    private static final int DB_VERSION = 1;

    public ConduceDatabase(Context context) { super(context, DB_NAME, null, DB_VERSION); }

    @Override public void onCreate(SQLiteDatabase db) {
        db.execSQL("CREATE TABLE " + TABLE + " ("
            + "id TEXT PRIMARY KEY NOT NULL, "
            + "saved_at INTEGER NOT NULL, "
            + "fecha TEXT NOT NULL DEFAULT '', "
            + "hora TEXT NOT NULL DEFAULT '', "
            + "localidad TEXT NOT NULL DEFAULT '', "
            + "tipo TEXT NOT NULL DEFAULT '', "
            + "persona TEXT NOT NULL DEFAULT '', "
            + "search_text TEXT NOT NULL DEFAULT '', "
            + "data_json TEXT NOT NULL)");
        db.execSQL("CREATE INDEX idx_conduces_fecha ON " + TABLE + "(fecha)");
        db.execSQL("CREATE INDEX idx_conduces_guardado ON " + TABLE + "(saved_at DESC)");
        db.execSQL("CREATE INDEX idx_conduces_localidad ON " + TABLE + "(localidad)");
    }

    @Override public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        // Las migraciones futuras deben preservar los registros.
    }

    private static String responsable(JSONObject data) {
        String nombre = data.optString("entNombre", "").trim();
        if (nombre.isEmpty()) nombre = "Terceros".equals(data.optString("tipo"))
            ? data.optString("chofer", "") : data.optString("nombreInterno", "");
        return nombre;
    }

    public synchronized boolean insertar(String id, long timestamp, JSONObject data) {
        if (data == null || timestamp <= 0) return false;
        if (id == null || id.isEmpty()) id = UUID.randomUUID().toString();
        ContentValues v = new ContentValues();
        v.put("id", id);
        v.put("saved_at", timestamp);
        v.put("fecha", data.optString("fecha"));
        v.put("hora", data.optString("hora"));
        v.put("localidad", data.optString("localidad"));
        v.put("tipo", data.optString("tipo"));
        v.put("persona", responsable(data));
        // La búsqueda incluye todos los campos, incluso materiales, conceptos y matrículas.
        v.put("search_text", (data.toString() + " " + responsable(data)).toLowerCase(Locale.ROOT));
        v.put("data_json", data.toString());
        return getWritableDatabase().insertWithOnConflict(TABLE, null, v,
            SQLiteDatabase.CONFLICT_IGNORE) != -1;
    }

    public synchronized int contar() {
        try (Cursor c = getReadableDatabase().rawQuery("SELECT COUNT(*) FROM " + TABLE, null)) {
            return c.moveToFirst() ? c.getInt(0) : 0;
        }
    }

    public synchronized String buscar(String term) {
        String q = term == null ? "" : term.trim().toLowerCase(Locale.ROOT);
        if (q.length() > 120) q = q.substring(0, 120);
        String where = q.isEmpty() ? null : "search_text LIKE ?";
        String[] args = q.isEmpty() ? null : new String[]{"%" + q + "%"};
        JSONArray rows = new JSONArray();
        // La base conserva TODO; la lista trae solamente los 200 registros más recientes coincidentes.
        try (Cursor c = getReadableDatabase().query(TABLE,
                new String[]{"id", "saved_at", "fecha", "hora", "localidad", "tipo", "persona"},
                where, args, null, null, "saved_at DESC", "200")) {
            while (c.moveToNext()) {
                JSONObject row = new JSONObject();
                row.put("id", c.getString(0));
                row.put("savedAt", c.getLong(1));
                row.put("fecha", c.getString(2));
                row.put("hora", c.getString(3));
                row.put("localidad", c.getString(4));
                row.put("tipo", c.getString(5));
                row.put("persona", c.getString(6));
                rows.put(row);
            }
        } catch (Exception e) { throw new IllegalStateException("Error consultando historial", e); }
        return rows.toString();
    }

    public synchronized String recuperar(String id) {
        if (id == null || id.length() > 96) return "";
        try (Cursor c = getReadableDatabase().query(TABLE, new String[]{"data_json"},
                "id = ?", new String[]{id}, null, null, null, "1")) {
            return c.moveToFirst() ? c.getString(0) : "";
        }
    }
}
