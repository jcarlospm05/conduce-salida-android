package com.bobc.conduce_salida_flutter;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.ActivityNotFoundException;
import android.content.ClipData;
import android.content.SharedPreferences;
import android.content.ContentValues;
import android.content.Intent;
import android.graphics.Color;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.Environment;
import android.provider.MediaStore;
import android.util.Base64;
import android.webkit.JavascriptInterface;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.Toast;
import org.json.JSONObject;
import org.json.JSONArray;
import java.util.UUID;

import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.OutputStream;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Locale;

/** Interfaz HTML local: guardar en Descargas o redactar correo con adjunto en Outlook. */
public final class ConducePlatformView implements io.flutter.plugin.platform.PlatformView {
    private final Activity activity;
    @Override public android.view.View getView() { return webView; }

    private static final int REQUEST_CREATE_DOCUMENT = 406;
    private static final String OUTLOOK_PACKAGE = "com.microsoft.office.outlook";
    // Solo dos registros privados: borrador de trabajo y último conduce, 24 horas.
    private static final String TEMP_PREFS = "conduce_temporal_24h";
    private static final long TEMP_TTL_MS = 24L * 60L * 60L * 1000L;
    private static final int TEMP_MAX_LENGTH = 120_000;
    private static final String HISTORY_KEY = "historial_conduces_json";

    private final ConduceDatabase database;

    /** Importa el historial temporal previo una sola vez, sin descartar por antigüedad. */
    private synchronized void migratePreviousConduceOnce() {
        SharedPreferences prefs = tempPreferences();
        if (prefs.getBoolean("historial_sqlite_migrado_v1", false)) return;
        try {
            JSONArray oldEntries = new JSONArray(prefs.getString(HISTORY_KEY, "[]"));
            for (int i = 0; i < oldEntries.length(); i++) {
                JSONObject entry = oldEntries.optJSONObject(i);
                if (entry == null) continue;
                JSONObject data = entry.optJSONObject("data");
                long timestamp = entry.optLong("savedAt", 0L);
                if (data != null && timestamp > 0 && !database.insertar(entry.optString("id"), timestamp, data)) {
                    // CONFLICT_IGNORE: un registro ya migrado se considera exitoso.
                    if (database.recuperar(entry.optString("id")).isEmpty()) return;
                }
            }
            String last = prefs.getString("ultimo_json", "");
            long ts = prefs.getLong("ultimo_fecha", 0L);
            if (last != null && !last.isEmpty() && ts > 0)
                database.insertar("anterior-" + ts, ts, new JSONObject(last));
            prefs.edit().putBoolean("historial_sqlite_migrado_v1", true).commit();
        } catch (Exception e) { message("No se pudo importar el historial anterior."); }
    }

    private void registerCompletedConduce(JSONObject snapshot) {
        if (snapshot == null) return;
        try {
            migratePreviousConduceOnce();
            if (!database.insertar(UUID.randomUUID().toString(), System.currentTimeMillis(), snapshot))
                throw new IllegalStateException("No se pudo registrar el documento");
            if (webView != null) webView.evaluateJavascript(
                "window.conduceHistorialActualizado && window.conduceHistorialActualizado();", null);
        } catch (Exception e) { message("El PDF se guardó, pero falló el registro en la base de datos."); }
    }

    private SharedPreferences tempPreferences() {
        return activity.getSharedPreferences(TEMP_PREFS, android.content.Context.MODE_PRIVATE);
    }

    private WebView webView;
    private File pendingLegacyFile;
    private JSONObject pendingLegacySnapshot;
    private boolean pendingLegacyOutlook;

    public ConducePlatformView(Activity activity) {
        this.activity = activity;
        this.database = new ConduceDatabase(activity);
        activity.getWindow().setStatusBarColor(Color.rgb(23, 55, 84));
        activity.getWindow().setNavigationBarColor(Color.rgb(23, 55, 84));
        webView = new WebView(activity);
        webView.setBackgroundColor(Color.WHITE);
        webView.setWebViewClient(new WebViewClient());
        WebSettings s = webView.getSettings();
        s.setJavaScriptEnabled(true);
        s.setDomStorageEnabled(false);
        s.setAllowFileAccess(true);
        s.setAllowContentAccess(false);
        s.setBuiltInZoomControls(false);
        s.setDisplayZoomControls(false);
        s.setDefaultTextEncodingName("UTF-8");
        webView.addJavascriptInterface(new DocumentBridge(), "ConduceAndroid");
        // El WebView se monta dentro de Flutter mediante AndroidView.
        webView.loadUrl("file:///android_asset/www/index.html");
    }

    private final class DocumentBridge {
        private static final int MAX_BASE64 = 24_000_000;
        private String action = "download";
        private JSONObject pendingSnapshot = null;
        private String name;
        private String mime;
        private StringBuilder encoded;

        // JS -> Android: almacenamiento privado por aplicación, sin nube ni permisos.
        @JavascriptInterface public synchronized boolean guardarTemporal(String tipo, String json) {
            if (!"borrador".equals(tipo) && !"ultimo".equals(tipo)) return false;
            if (json == null || json.length() > TEMP_MAX_LENGTH) return false;
            try {
                JSONObject checked = new JSONObject(json);
                if (checked.length() == 0) return false;
                tempPreferences().edit()
                    .putString(tipo + "_json", checked.toString())
                    .putLong(tipo + "_fecha", System.currentTimeMillis())
                    .apply();
                return true;
            } catch (Exception e) { return false; }
        }

        @JavascriptInterface public synchronized String leerTemporal(String tipo) {
            if (!"borrador".equals(tipo) && !"ultimo".equals(tipo)) return "";
            SharedPreferences prefs = tempPreferences();
            String json = prefs.getString(tipo + "_json", "");
            long fecha = prefs.getLong(tipo + "_fecha", 0L);
            long now = System.currentTimeMillis();
            if (json == null || json.isEmpty() || fecha <= 0L) return "";
            if (fecha > now + 60_000L || now - fecha >= TEMP_TTL_MS) {
                borrarTemporal(tipo);
                return "";
            }
            try {
                JSONObject wrapper = new JSONObject();
                wrapper.put("savedAt", fecha);
                wrapper.put("data", new JSONObject(json));
                return wrapper.toString();
            } catch (Exception ex) {
                borrarTemporal(tipo);
                return "";
            }
        }

        @JavascriptInterface public synchronized void borrarTemporal(String tipo) {
            if (!"borrador".equals(tipo) && !"ultimo".equals(tipo)) return;
            tempPreferences().edit().remove(tipo + "_json").remove(tipo + "_fecha").apply();
        }


        @JavascriptInterface public synchronized String listarConduces() {
            return buscarConduces("");
        }

        @JavascriptInterface public synchronized String buscarConduces(String consulta) {
            try {
                migratePreviousConduceOnce();
                return database.buscar(consulta);
            } catch (Exception ignored) { return "[]"; }
        }

        @JavascriptInterface public synchronized int cantidadConduces() {
            try { migratePreviousConduceOnce(); return database.contar(); }
            catch (Exception ignored) { return 0; }
        }

        @JavascriptInterface public synchronized String recuperarConduce(String id) {
            try { migratePreviousConduceOnce(); return database.recuperar(id); }
            catch (Exception ignored) { return ""; }
        }

        @JavascriptInterface public synchronized boolean setPendingConduce(String json) {
            pendingSnapshot = null;
            if (json == null || json.length() > TEMP_MAX_LENGTH) return false;
            try {
                pendingSnapshot = new JSONObject(json);
                return true;
            } catch (Exception ex) { return false; }
        }

        @JavascriptInterface public synchronized void setAction(String requested) {
            action = "save_outlook".equals(requested) ? "save_outlook"
                : "outlook".equals(requested) ? "outlook" : "download";
        }

        @JavascriptInterface public synchronized void startShare(String filename, String contentType) {
            String safe = filename == null ? "Conduce_Salida.pdf" : filename.replaceAll("[^a-zA-Z0-9_.-]", "_");
            if (!safe.matches("[a-zA-Z0-9_.-]{1,110}\\.(pdf|docx|xlsx)")) {
                name = null; encoded = null;
                message("Nombre de archivo no válido."); return;
            }
            name = safe;
            mime = safe.endsWith(".pdf") ? "application/pdf" : safe.endsWith(".docx")
                ? "application/vnd.openxmlformats-officedocument.wordprocessingml.document"
                : "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet";
            encoded = new StringBuilder(200_000);
        }

        @JavascriptInterface public synchronized void appendChunk(String chunk) {
            if (encoded == null || chunk == null) return;
            if (encoded.length() + chunk.length() > MAX_BASE64) {
                encoded = null; message("El documento excede el tamaño permitido."); return;
            }
            encoded.append(chunk);
        }

        @JavascriptInterface public synchronized void finishShare() {
            if (encoded == null || name == null) return;
            byte[] data;
            try { data = Base64.decode(encoded.toString(), Base64.DEFAULT); }
            catch (IllegalArgumentException e) {
                encoded = null; message("No se pudo leer el documento generado."); return;
            }
            encoded = null;
            String selectedAction = action;
            String type = mime;
            String filename = withTimestamp(name);
            JSONObject snapshot = pendingSnapshot;
            pendingSnapshot = null;
            action = "download";
            if ("save_outlook".equals(selectedAction)) {
                if (!"application/pdf".equals(type) || snapshot == null) {
                    message("No se pudo preparar el PDF o los datos del conduce."); return;
                }
                activity.runOnUiThread(() -> savePdfAndSendOutlook(data, filename, snapshot));
            } else if ("outlook".equals(selectedAction)) {
                try {
                    File dir = new File(activity.getCacheDir(), "compartidos");
                    if (!dir.exists() && !dir.mkdirs()) throw new IOException("No se pudo preparar el adjunto.");
                    File cached = new File(dir, filename);
                    try (FileOutputStream out = new FileOutputStream(cached)) { out.write(data); }
                    Uri uri = new Uri.Builder().scheme("content")
                        .authority(activity.getPackageName() + ".shared").appendPath(filename).build();
                    activity.runOnUiThread(() -> openOutlook(uri, type));
                } catch (Exception e) { message("Error preparando Outlook: " + e.getMessage()); }
            } else {
                activity.runOnUiThread(() -> saveDocument(data, filename, type));
            }
        }

        private String withTimestamp(String filename) {
            int dot = filename.lastIndexOf('.');
            String suffix = new SimpleDateFormat("_HHmmss_SSS", Locale.US).format(new Date());
            return filename.substring(0, dot) + suffix + filename.substring(dot);
        }
    }

    /** Primero guardar PDF real; solo después registrar y abrir Outlook con el adjunto. */
    private void savePdfAndSendOutlook(byte[] pdf, String filename, JSONObject snapshot) {
        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.Q) {
            // Android 8/9: se requiere escoger una carpeta mediante el selector de Android.
            try {
                File dir = new File(activity.getCacheDir(), "pendiente");
                if (!dir.exists() && !dir.mkdirs()) throw new IOException("Carpeta inaccesible.");
                pendingLegacyFile = new File(dir, filename);
                try (FileOutputStream output = new FileOutputStream(pendingLegacyFile)) { output.write(pdf); }
                pendingLegacySnapshot = snapshot;
                pendingLegacyOutlook = true;
                Intent create = new Intent(Intent.ACTION_CREATE_DOCUMENT);
                create.addCategory(Intent.CATEGORY_OPENABLE);
                create.setType("application/pdf");
                create.putExtra(Intent.EXTRA_TITLE, filename);
                activity.startActivityForResult(create, REQUEST_CREATE_DOCUMENT);
            } catch (Exception e) { message("No se pudo guardar el PDF: " + e.getMessage()); }
            return;
        }
        Uri uri = null;
        try {
            ContentValues cv = new ContentValues();
            cv.put(MediaStore.MediaColumns.DISPLAY_NAME, filename);
            cv.put(MediaStore.MediaColumns.MIME_TYPE, "application/pdf");
            cv.put(MediaStore.MediaColumns.RELATIVE_PATH, Environment.DIRECTORY_DOWNLOADS + "/Conduce Salida");
            cv.put(MediaStore.MediaColumns.IS_PENDING, 1);
            uri = activity.getContentResolver().insert(MediaStore.Downloads.EXTERNAL_CONTENT_URI, cv);
            if (uri == null) throw new IOException("Android no permitió crear el PDF.");
            try (OutputStream output = activity.getContentResolver().openOutputStream(uri)) {
                if (output == null) throw new IOException("No se pudo abrir el destino.");
                output.write(pdf);
            }
            ContentValues done = new ContentValues();
            done.put(MediaStore.MediaColumns.IS_PENDING, 0);
            activity.getContentResolver().update(uri, done, null, null);
            registerCompletedConduce(snapshot);
            message("PDF guardado en Descargas / Conduce Salida. Abriendo Outlook…");
            openOutlook(uri, "application/pdf");
        } catch (Exception e) {
            if (uri != null) activity.getContentResolver().delete(uri, null, null);
            message("No se pudo guardar el PDF; Outlook no se abrirá: " + e.getMessage());
        }
    }

    private void saveDocument(byte[] data, String filename, String mime) {
        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.Q) {
            // Android 8-9: selector SAF, sin permisos invasivos de almacenamiento.
            try {
                File dir = new File(activity.getCacheDir(), "pendiente");
                if (!dir.exists() && !dir.mkdirs()) throw new IOException("Error de carpeta.");
                pendingLegacyFile = new File(dir, filename);
                try (FileOutputStream out = new FileOutputStream(pendingLegacyFile)) { out.write(data); }
                Intent create = new Intent(Intent.ACTION_CREATE_DOCUMENT);
                create.addCategory(Intent.CATEGORY_OPENABLE);
                create.setType(mime);
                create.putExtra(Intent.EXTRA_TITLE, filename);
                activity.startActivityForResult(create, REQUEST_CREATE_DOCUMENT);
            } catch (Exception e) { message("No se pudo abrir Guardar como: " + e.getMessage()); }
            return;
        }
        Uri uri = null;
        try {
            ContentValues cv = new ContentValues();
            cv.put(MediaStore.MediaColumns.DISPLAY_NAME, filename);
            cv.put(MediaStore.MediaColumns.MIME_TYPE, mime);
            cv.put(MediaStore.MediaColumns.RELATIVE_PATH, Environment.DIRECTORY_DOWNLOADS + "/Conduce Salida");
            cv.put(MediaStore.MediaColumns.IS_PENDING, 1);
            uri = activity.getContentResolver().insert(MediaStore.Downloads.EXTERNAL_CONTENT_URI, cv);
            if (uri == null) throw new IOException("Android no autorizó la descarga.");
            try (OutputStream out = activity.getContentResolver().openOutputStream(uri)) {
                if (out == null) throw new IOException("No se pudo abrir el archivo.");
                out.write(data);
            }
            ContentValues done = new ContentValues();
            done.put(MediaStore.MediaColumns.IS_PENDING, 0);
            activity.getContentResolver().update(uri, done, null, null);
            message("Guardado en Descargas / Conduce Salida / " + filename);
        } catch (Exception e) {
            if (uri != null) activity.getContentResolver().delete(uri, null, null);
            message("No se pudo guardar en Descargas: " + e.getMessage());
        }
    }

    public void handleActivityResult(int request, int result, Intent intent) {
        if (request != REQUEST_CREATE_DOCUMENT) return;
        File cached = pendingLegacyFile;
        pendingLegacyFile = null;
        if (result != Activity.RESULT_OK || intent == null || intent.getData() == null || cached == null) {
            pendingLegacyOutlook = false;
            pendingLegacySnapshot = null;
            message("No se guardó el documento."); return;
        }
        try (java.io.FileInputStream in = new java.io.FileInputStream(cached);
             OutputStream out = activity.getContentResolver().openOutputStream(intent.getData())) {
            if (out == null) throw new IOException("El destino no está disponible.");
            byte[] buf = new byte[16384]; int n;
            while ((n = in.read(buf)) >= 0) out.write(buf, 0, n);
            if (pendingLegacyOutlook) {
                registerCompletedConduce(pendingLegacySnapshot);
                message("PDF guardado. Abriendo Outlook…");
                openOutlook(intent.getData(), "application/pdf");
            } else message("Documento guardado en la carpeta que elegiste.");
        } catch (Exception e) { message("No se pudo guardar: " + e.getMessage()); }
        finally {
            cached.delete();
            pendingLegacyOutlook = false;
            pendingLegacySnapshot = null;
        }
    }

    private void openOutlook(Uri uri, String mime) {
        Intent email = new Intent(Intent.ACTION_SEND);
        email.setPackage(OUTLOOK_PACKAGE); // No abre Gmail ni un selector genérico.
        email.setType(mime);
        email.putExtra(Intent.EXTRA_STREAM, uri);
        email.putExtra(Intent.EXTRA_SUBJECT, "Conduce de salida");
        email.putExtra(Intent.EXTRA_TEXT, "Adjunto el conduce de salida para imprimir en hoja carta.");
        email.setClipData(ClipData.newRawUri("Conduce de salida", uri));
        email.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);
        try {
            activity.grantUriPermission(OUTLOOK_PACKAGE, uri, Intent.FLAG_GRANT_READ_URI_PERMISSION);
            activity.startActivity(email);
        } catch (ActivityNotFoundException ex) {
            new AlertDialog.Builder(activity)
                .setTitle("Outlook no está disponible")
                .setMessage("Instala Microsoft Outlook o inicia sesión en la aplicación para enviar el PDF.")
                .setNegativeButton("Cancelar", null)
                .setPositiveButton("Abrir Google Play", (dialog, which) -> {
                    Intent link = new Intent(Intent.ACTION_VIEW,
                        Uri.parse("https://play.google.com/store/apps/details?id=" + OUTLOOK_PACKAGE));
                    try { activity.startActivity(link); } catch (Exception ignored) {
                        message("No se pudo abrir Google Play.");
                    }
                }).show();
        } catch (Exception ex) { message("No se pudo abrir Outlook: " + ex.getMessage()); }
    }

    private void message(String text) {
        activity.runOnUiThread(() -> {
            Toast.makeText(activity, text, Toast.LENGTH_LONG).show();
            if (webView != null) {
                String js = "window.conduceAvisoAndroid && window.conduceAvisoAndroid(" +
                    org.json.JSONObject.quote(text) + ");";
                webView.evaluateJavascript(js, null);
            }
        });
    }

    public void handleBackPressed(Runnable exit) {
        if (webView == null) { exit.run(); return; }
        webView.evaluateJavascript("(function(){try{window.conduceGuardarTemporalAhora&&window.conduceGuardarTemporalAhora()}catch(e){}return Boolean(window.conduceVolverAndroid&&window.conduceVolverAndroid())})()", result -> {
            if (!"true".equals(result)) {
                new AlertDialog.Builder(activity).setTitle("Cerrar formulario")
                    .setMessage("Podrás recuperar el borrador durante 24 horas. ¿Salir?")
                    .setNegativeButton("Cancelar", null)
                    .setPositiveButton("Salir", (dialog, which) -> activity.finish()).show();
            }
        });
    }

    @Override public void dispose() {
        if (webView != null) {
            webView.removeJavascriptInterface("ConduceAndroid");
            webView.destroy(); webView = null;
        }
    }
}
