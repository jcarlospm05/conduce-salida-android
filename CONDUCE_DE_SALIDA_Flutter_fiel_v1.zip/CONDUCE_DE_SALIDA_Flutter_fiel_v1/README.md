# Conduce de Salida — Migración fiel a Flutter

**Objetivo:** conservar exactamente la interfaz HTML, el reporte carta original, su logotipo y el flujo Android v3.6. Sin rediseño.

## Implementación
- Flutter aloja un `AndroidView` de la interfaz original sin alterar un solo archivo HTML/CSS/JS.
- `ConducePlatformView.java` conserva el puente Java con PDF, Descargas y Outlook.
- Icono y logo se copian del proyecto original.
- Estado funcional exacto de la fuente v3.6: historial temporal de **24 horas**, como en el original.
- NO es una reescritura completa de la lógica a Dart: esta solución Flutter es híbrida para preservar la fidelidad total del documento y de la experiencia de uso.
- La base SQLite permanente y consultas de auditoría de PORTA no están integradas: priorizamos el pedido de que todo sea igual al original.

## Compilar

En GitHub, rama `conduce-flutter-fiel` → Actions → `Flutter Conduce de Salida - APK` → artefacto `Conduce-de-Salida-Flutter-APK`.

Comando local (Flutter SDK y Android SDK):

```bash
flutter create . --platforms android --org com.bobc --project-name conduce_salida_flutter
mkdir -p android/app/src/main/java/com/bobc/conduce_salida_flutter
cp android_native/java/com/bobc/conduce_salida_flutter/*.java android/app/src/main/java/com/bobc/conduce_salida_flutter/
rm -f android/app/src/main/kotlin/com/bobc/conduce_salida_flutter/MainActivity.kt
cp android_native/AndroidManifest.xml android/app/src/main/AndroidManifest.xml
cp -r android_native/res/. android/app/src/main/res/
mkdir -p android/app/src/main/assets/www
cp -r android_native/www/. android/app/src/main/assets/www/
flutter pub get
flutter build apk --debug
```

El identificador de paquete es `com.bobc.conduce_salida_flutter`, diferente del original, para instalarse sin sobrescribirlo.

No entregar como producción hasta validar visualmente y probar en Android la exportación PDF, guardado y apertura de Outlook.
