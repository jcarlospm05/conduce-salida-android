package com.bobc.conduce_salida_flutter;

import android.content.Context;
import android.content.Intent;
import android.view.View;
import androidx.annotation.NonNull;
import io.flutter.embedding.android.FlutterActivity;
import io.flutter.embedding.engine.FlutterEngine;
import io.flutter.plugin.common.MessageCodec;
import io.flutter.plugin.common.StandardMessageCodec;
import io.flutter.plugin.platform.PlatformView;
import io.flutter.plugin.platform.PlatformViewFactory;

/** Arranca el diseño original 1:1 dentro de una aplicación Flutter. */
public final class MainActivity extends FlutterActivity {
    private ConducePlatformView view;

    @Override public void configureFlutterEngine(@NonNull FlutterEngine engine) {
        super.configureFlutterEngine(engine);
        engine.getPlatformViewsController().getRegistry().registerViewFactory(
            "bobc.conduce.original", new PlatformViewFactory(StandardMessageCodec.INSTANCE) {
                @Override public PlatformView create(Context context, int viewId, Object args) {
                    view = new ConducePlatformView(MainActivity.this);
                    return view;
                }
            }
        );
    }

    @Override protected void onActivityResult(int request, int result, Intent intent) {
        super.onActivityResult(request, result, intent);
        if (view != null) view.handleActivityResult(request, result, intent);
    }

    @Override public void onBackPressed() {
        if (view != null) view.handleBackPressed(() -> MainActivity.super.onBackPressed());
        else super.onBackPressed();
    }
}
