import 'package:flutter/material.dart';

/// El contenedor Flutter no altera la interfaz ni el documento originales.
/// AndroidView integra el WebView original y su puente Android, sin rediseñar.
void main() => runApp(const ConduceDeSalidaApp());

class ConduceDeSalidaApp extends StatelessWidget {
  const ConduceDeSalidaApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Conduce de Salida',
      debugShowCheckedModeBanner: false,
      theme: ThemeData(useMaterial3: false, scaffoldBackgroundColor: Colors.white),
      home: const ConduceOriginalScreen(),
    );
  }
}

class ConduceOriginalScreen extends StatelessWidget {
  const ConduceOriginalScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return const Scaffold(
      resizeToAvoidBottomInset: false,
      body: SafeArea(
        top: false,
        bottom: false,
        child: AndroidView(viewType: 'bobc.conduce.original'),
      ),
    );
  }
}
