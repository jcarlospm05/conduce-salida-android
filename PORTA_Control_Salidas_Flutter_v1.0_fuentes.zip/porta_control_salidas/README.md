# PORTA — Control de Salidas (Flutter)

Proyecto **independiente** de la aplicación anterior *Conduce Salida*.

## Identidad y funcionamiento
- Nombre e ícono nuevos: PORTA (puerta, documento y flecha de salida).
- Interfaz empresarial: azul marino, verde oscuro, gris pizarra, negro y marrón.
- PDF de una hoja **carta**, con distribución original: encabezado, fecha/hora, localidad, tipo, concepto, dos sectores simultáneos, autorizaciones y nota final.
- Sólo el sector elegido imprime contenido; el otro queda en blanco.
- Guardar y enviar: documento en Descargas/PORTA, intenta abrir Outlook con el PDF adjunto, la persona **confirma el envío manualmente**.
- Historial ilimitado sin caducidad, consulta de textos, filtro de tipo y fechas, duplicación, edición versionada, auditoría persistente e inmutable en SQLite.
- En web usa IndexedDB (Sembast). SQLite se usa en Android.
- Sin Supabase, sin Internet obligatorio para la APK.

## Estructura
- `lib/models/` contratos.
- `lib/data/` repositorios Android SQLite y Web IndexedDB.
- `lib/services/` PDF, compartir y respaldo.
- `lib/features/` pantallas.
- `lib/core/` tema y validadores.
- `android_native/` puente Android para Descargas y Outlook.
- `.github/workflows/` test y compilación APK + web.

## Uso local (Flutter SDK instalado)
```bash
flutter create . --platforms android,web --org com.bobc --project-name porta_control_salidas
cp android_native/MainActivity.kt android/app/src/main/kotlin/com/bobc/porta_control_salidas/MainActivity.kt
flutter pub get
dart run flutter_launcher_icons
flutter test
flutter analyze
flutter run -d chrome
flutter build apk --debug
```

En GitHub Actions, `Run workflow` genera artefactos Android y Web para probar, no una APK de distribución firmada con keystore de producción.

## Datos, recuperación y auditoría
Los registros no se eliminan automáticamente. Al actualizar un conduce, se añade un evento de auditoría con datos previos y posteriores. Los registros existentes no se borran. El respaldo JSON se puede exportar; la restauración JSON está disponible en el menú de historial y realiza importación conservadora.

**Advertencias:** no puede garantizarse conservación si se desinstala la app o se pierde el dispositivo sin respaldo externo. Tampoco se ha certificado aún la fidelidad visual píxel a píxel del PDF respecto al original.

## Licencia del código
Uso interno BOBC. Los logotipos y documentos de terceros permanecen bajo los derechos de sus titulares.
