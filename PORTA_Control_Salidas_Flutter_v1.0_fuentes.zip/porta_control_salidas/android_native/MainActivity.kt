package com.bobc.porta_control_salidas

import android.app.Activity
import android.content.ContentValues
import android.content.Intent
import android.net.Uri
import android.os.Build
import android.os.Environment
import android.provider.MediaStore
import io.flutter.embedding.android.FlutterActivity
import io.flutter.embedding.engine.FlutterEngine
import io.flutter.plugin.common.MethodChannel

class MainActivity : FlutterActivity() {
    private var pending: MethodChannel.Result? = null
    private var pendingBytes: ByteArray? = null
    private var pendingName: String = ""
    private val requestDocument = 2213

    override fun configureFlutterEngine(flutterEngine: FlutterEngine) {
        super.configureFlutterEngine(flutterEngine)
        MethodChannel(flutterEngine.dartExecutor.binaryMessenger, "com.bobc.porta/exports")
            .setMethodCallHandler { call, result ->
                if (call.method != "saveAndOpenOutlook") {
                    result.notImplemented(); return@setMethodCallHandler
                }
                val name = call.argument<String>("filename") ?: "PORTA.pdf"
                val bytes = call.argument<ByteArray>("bytes")
                if (bytes == null || bytes.isEmpty()) {
                    result.error("PDF", "Documento vacío", null); return@setMethodCallHandler
                }
                if (Build.VERSION.SDK_INT >= 29) {
                    try {
                        val values = ContentValues().apply {
                            put(MediaStore.Downloads.DISPLAY_NAME, name)
                            put(MediaStore.Downloads.MIME_TYPE, "application/pdf")
                            put(MediaStore.Downloads.RELATIVE_PATH, "${Environment.DIRECTORY_DOWNLOADS}/PORTA")
                        }
                        val uri = contentResolver.insert(MediaStore.Downloads.EXTERNAL_CONTENT_URI, values)
                            ?: throw IllegalStateException("No se pudo crear PDF")
                        contentResolver.openOutputStream(uri)?.use { it.write(bytes) }
                            ?: throw IllegalStateException("No se pudo escribir PDF")
                        val opened = openOutlook(uri)
                        result.success(mapOf("saved" to true,"outlookOpened" to opened,
                            "message" to if (opened) "PDF guardado. Revisa y envía desde Outlook" else "PDF guardado en Descargas/PORTA. Outlook no disponible"))
                    } catch (e: Exception) { result.error("SAVE",e.message,null) }
                } else {
                    pending=result;pendingBytes=bytes;pendingName=name
                    val intent=Intent(Intent.ACTION_CREATE_DOCUMENT).apply {
                        addCategory(Intent.CATEGORY_OPENABLE);type="application/pdf"
                        putExtra(Intent.EXTRA_TITLE,name)
                    }
                    startActivityForResult(intent,requestDocument)
                }
            }
    }
    @Deprecated("Compatibility for Android 8/9 file picker")
    override fun onActivityResult(requestCode: Int,resultCode: Int,data: Intent?) {
        super.onActivityResult(requestCode,resultCode,data)
        if(requestCode != requestDocument)return
        val callback=pending;val bytes=pendingBytes
        pending=null;pendingBytes=null
        if(resultCode!=Activity.RESULT_OK||data?.data==null){callback?.error("CANCEL","Guardado cancelado",null);return}
        try {
            val uri=data.data!!
            contentResolver.openOutputStream(uri)?.use { it.write(bytes?:ByteArray(0)) }
                ?:throw IllegalStateException("No se pudo guardar archivo")
            val opened=openOutlook(uri)
            callback?.success(mapOf("saved" to true,"outlookOpened" to opened,
                "message" to if(opened)"PDF guardado. Revisa Outlook" else "PDF guardado. Outlook no disponible"))
        }catch(e:Exception){callback?.error("SAVE",e.message,null)}
    }
    private fun openOutlook(uri: Uri): Boolean {
        return try {
            val intent=Intent(Intent.ACTION_SEND).apply {
                type="application/pdf";putExtra(Intent.EXTRA_STREAM,uri)
                addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
                setPackage("com.microsoft.office.outlook")
            }
            startActivity(intent)
            true
        }catch(e:Exception){false}
    }
}
