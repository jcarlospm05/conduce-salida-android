import 'package:flutter_test/flutter_test.dart';
import 'package:porta_control_salidas/models/salida.dart';
import 'package:porta_control_salidas/core/validation.dart';
void main(){
  test('No imprime datos del sector inactivo',(){
    final s=Salida.nueva().copyWith(tipo:'Interno',campos:{'nombreInterno':'Ana','empresa':'No imprimir'});
    expect(s.imprimible.campo('empresa'),'');expect(s.imprimible.campo('nombreInterno'),'Ana');
  });
  test('Conduce requiere localidad, tipo y concepto',(){
    expect(ValidadorSalida.errores(Salida.nueva()),isNotEmpty);
  });
  test('Historial serializa datos sin pérdida',(){
    final s=Salida.nueva().copyWith(materiales:'1 martillo - 2 cajas');
    expect(Salida.fromJson(s.toJson()).materiales,s.materiales);
  });
}
