import 'dart:convert';

class Salida {
  final String id;
  final String fecha;
  final String hora;
  final String localidad;
  final String tipo;
  final List<String> conceptos;
  final Map<String, String> campos;
  final String materiales;
  final String createdAt;
  final String updatedAt;
  final int revision;

  const Salida({required this.id, required this.fecha, required this.hora,
    required this.localidad, required this.tipo, required this.conceptos,
    required this.campos, required this.materiales, required this.createdAt,
    required this.updatedAt, required this.revision});

  static const localidades = ['TSB', 'TRH', 'OP', 'PTP', 'STI'];
  static const tipos = ['Terceros', 'Interno'];
  static const conceptosValidos = ['Venta bienes', 'Servicio rescate', 'Despacho', 'Mantenimiento'];

  static const keys = [
    'empresa','rnc','chofer','cedulaChofer','cantidadTerceros','disposicionTerceros',
    'nombreInterno','posicionInterno','cantidadInterno','ubicacionInterno','disposicionInterno',
    'autNombre','autPosicion','autFecha','autFirma',
    'entNombre','entPosicion','entPlaca','entFecha','entFirma'
  ];
  factory Salida.nueva() {
    final now = DateTime.now();
    String two(int n) => n.toString().padLeft(2,'0');
    final local = '${now.year}-${two(now.month)}-${two(now.day)}';
    return Salida(id: '',fecha:local,hora:'${two(now.hour)}:${two(now.minute)}',
      localidad:'',tipo:'',conceptos:const [],campos:{for(final k in keys) k:''},
      materiales:'',createdAt:'',updatedAt:'',revision:0);
  }
  Salida copyWith({String? id,String? fecha,String? hora,String? localidad,String? tipo,
    List<String>? conceptos,Map<String,String>? campos,String? materiales,
    String? createdAt,String? updatedAt,int? revision}) => Salida(
      id:id??this.id,fecha:fecha??this.fecha,hora:hora??this.hora,
      localidad:localidad??this.localidad,tipo:tipo??this.tipo,
      conceptos:conceptos??this.conceptos,campos:campos??this.campos,
      materiales:materiales??this.materiales,createdAt:createdAt??this.createdAt,
      updatedAt:updatedAt??this.updatedAt,revision:revision??this.revision);
  String campo(String key) => campos[key] ?? '';
  String get persona => tipo=='Terceros'?campo('chofer'):campo('nombreInterno');
  String get nombre => persona.trim().isEmpty?'Sin responsable':persona.trim();
  Salida get imprimible {
    final fields=Map<String,String>.from(campos);
    if(tipo=='Interno') {
      for(final k in ['empresa','rnc','chofer','cedulaChofer','cantidadTerceros','disposicionTerceros']) {fields[k]='';}
    } else if(tipo=='Terceros') {
      for(final k in ['nombreInterno','posicionInterno','cantidadInterno','ubicacionInterno','disposicionInterno']) {fields[k]='';}
    }
    return copyWith(campos: fields);
  }
  Map<String,dynamic> toJson()=>{
    'id':id,'fecha':fecha,'hora':hora,'localidad':localidad,'tipo':tipo,
    'conceptos':conceptos,'campos':campos,'materiales':materiales,
    'createdAt':createdAt,'updatedAt':updatedAt,'revision':revision};
  factory Salida.fromJson(Map<String,dynamic> j)=> Salida(
    id:'${j['id']??''}',fecha:'${j['fecha']??''}',hora:'${j['hora']??''}',
    localidad:'${j['localidad']??''}',tipo:'${j['tipo']??''}',
    conceptos:List<String>.from(j['conceptos']??const []),
    campos:(j['campos'] as Map? ??{}).map((k,v)=>MapEntry('$k','$v')),
    materiales:'${j['materiales']??''}',createdAt:'${j['createdAt']??''}',
    updatedAt:'${j['updatedAt']??''}',revision:(j['revision'] as num?)?.toInt()??0);
  String encode()=>jsonEncode(toJson());
}

class Auditoria {
  final int id;
  final String salidaId,accion,fecha,antes,despues,actor;
  const Auditoria(this.id,this.salidaId,this.accion,this.fecha,this.antes,this.despues,this.actor);
}
