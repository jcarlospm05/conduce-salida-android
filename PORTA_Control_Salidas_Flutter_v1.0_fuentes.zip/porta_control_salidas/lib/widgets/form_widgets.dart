import 'package:flutter/material.dart';
import '../core/porta_theme.dart';
class SectionCard extends StatelessWidget {
  final String title; final Widget child; const SectionCard({super.key,required this.title,required this.child});
  @override Widget build(BuildContext context)=>Card(child:Padding(padding:const EdgeInsets.all(16),child:Column(
    crossAxisAlignment:CrossAxisAlignment.stretch,children:[Text(title,style:Theme.of(context).textTheme.titleMedium?.copyWith(
      fontWeight:FontWeight.w800,color:PortaColors.navy)),const SizedBox(height:14),child])));
}
class SelectChips extends StatelessWidget {
  final List<String> items,selected;final bool multi;final ValueChanged<List<String>> onChanged;
  const SelectChips({super.key,required this.items,required this.selected,required this.onChanged,this.multi=false});
  @override Widget build(BuildContext context)=>Wrap(spacing:8,runSpacing:6,children:items.map((value)=>ChoiceChip(
    label:Text(value),selected:selected.contains(value),onSelected:(yes){
      if(multi){onChanged(yes?[...selected,value]:selected.where((e)=>e!=value).toList());}
      else{onChanged(yes?[value]:[]);}
    })).toList());
}
