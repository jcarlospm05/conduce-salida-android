import 'dart:convert';
import 'package:file_picker/file_picker.dart';
import '../data/salida_repository.dart';

class BackupService {
  static Future<int?> importJson(SalidaRepository repository)async{
    final file=await FilePicker.pickFile(type:FileType.custom,allowedExtensions:['json']);
    if(file==null)return null;
    final bytes=await file.readAsBytes();
    return repository.restore(utf8.decode(bytes));
  }
}
