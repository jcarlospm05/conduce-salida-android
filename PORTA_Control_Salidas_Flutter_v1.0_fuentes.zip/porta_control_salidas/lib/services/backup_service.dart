import 'dart:convert';
import 'package:file_picker/file_picker.dart';
import '../data/salida_repository.dart';

class BackupService {
  static Future<int?> importJson(SalidaRepository repository)async{
    final picked=await FilePicker.platform.pickFiles(type:FileType.custom,
      allowedExtensions:['json'],withData:true);
    if(picked==null||picked.files.isEmpty)return null;
    final bytes=picked.files.single.bytes;
    if(bytes==null)throw const FormatException('No se pudieron leer los bytes del respaldo');
    return repository.restore(utf8.decode(bytes));
  }
}
