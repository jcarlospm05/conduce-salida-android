import 'dart:convert';
import 'package:flutter/foundation.dart';
import 'package:flutter/services.dart';
import 'package:printing/printing.dart';
import 'package:share_plus/share_plus.dart';
import '../models/salida.dart';
import '../data/salida_repository.dart';
import 'pdf_service.dart';

class ExportService {
  static const native=MethodChannel('com.bobc.porta/exports');
  static Future<String> saveAndSend(Salida salida)async{
    final content=await PdfService.generate(salida);
    final filename='PORTA_${salida.fecha.replaceAll('-','')}_${salida.id.split('-').last}.pdf';
    if(!kIsWeb && defaultTargetPlatform==TargetPlatform.android){
      final result=await native.invokeMethod<Map<Object?,Object?>>('saveAndOpenOutlook',{
        'filename':filename,'bytes':content});
      return '${result?['message']??'Documento guardado'}';
    }
    await Printing.sharePdf(bytes:content,filename:filename);
    return 'PDF preparado para compartir desde el navegador';
  }
  static Future<void> preview(Salida salida)async{
    await Printing.layoutPdf(onLayout:(_)=>PdfService.generate(salida));
  }
  static Future<void> backup(SalidaRepository repo)async{
    final content=Uint8List.fromList(utf8.encode(await repo.backup()));
    final filename='PORTA_respaldo_${DateTime.now().millisecondsSinceEpoch}.json';
    await SharePlus.instance.share(ShareParams(files:[XFile.fromData(content,mimeType:'application/json',name:filename)],
      fileNameOverrides:[filename],text:'Respaldo de PORTA. Guárdalo fuera del dispositivo.'));
  }
}
