import 'package:flutter/services.dart';
import 'package:pdf/pdf.dart';
import 'package:pdf/widgets.dart' as pw;
import '../models/salida.dart';

/// Letter format and positions follow the legacy 816x1056 CSS form scaled to 612x792pt.
/// Interface styles may change; this layout remains monochrome and independent.
class PdfService {
  static const double s=.75;
  static pw.TextStyle txt([double px=10,bool bold=false])=>pw.TextStyle(
    font: bold?pw.Font.helveticaBold():pw.Font.helvetica(),fontSize:px*s,color:PdfColors.black);
  static pw.Widget positioned(double x,double y,double width,double height,pw.Widget child)=>
    pw.Positioned(left:x*s,top:y*s,child:pw.SizedBox(width:width*s,height:height*s,child:child));
  static pw.Widget line(String label,String val,double height,{double labelPercent=.37})=>
    pw.Container(height:height*s,decoration:const pw.BoxDecoration(border:pw.Border(bottom:pw.BorderSide(width:.5))),
      child:pw.Row(children:[
        pw.Container(width:(726/2)*s*labelPercent,alignment:pw.Alignment.centerLeft,
          decoration:const pw.BoxDecoration(border:pw.Border(right:pw.BorderSide(width:.5))),
          padding:const pw.EdgeInsets.all(3),child:pw.Text(label,style:txt(9.5,true),maxLines:3)),
        pw.Expanded(child:pw.Padding(padding:const pw.EdgeInsets.all(3),child:pw.Text(val,style:txt(10),maxLines:height>140?8:3)))
      ]));
  static pw.Widget sector(Salida d,{required bool internal}){
    final isActive=d.tipo==(internal?'Interno':'Terceros');
    final mat=isActive?d.materiales:'';
    String c(String key)=>isActive?d.campo(key):'';
    final parts=<pw.Widget>[
      pw.Container(height:21*s,alignment:pw.Alignment.center,
        decoration:const pw.BoxDecoration(border:pw.Border(bottom:pw.BorderSide(width:.5))),
        child:pw.Text(internal?'En caso personal interno':'En caso de terceros',style:txt(10,true))),
      if(!internal)...[
        line('Empresa:',c('empresa'),27),line('RNC:',c('rnc'),27),
        line('Nombre y apellidos chofer:',c('chofer'),31),line('Cédula chofer:',c('cedulaChofer'),27),
        line('Herramientas, materiales o bienes:',mat,157),
        line('Cantidad:',c('cantidadTerceros'),27),
        line('Breve descripción disposición final herramientas, materiales o bienes:',c('disposicionTerceros'),80),
      ]else...[
        line('Nombre y apellidos:',c('nombreInterno'),27),line('Posición:',c('posicionInterno'),27),
        line('Herramientas, materiales o bienes:',mat,157),
        line('Cantidad:',c('cantidadInterno'),27),
        line('Breve descripción disposición final herramientas, materiales o bienes:',c('disposicionInterno'),80),
        line('Ubicación en caso de servicio de rescate:',c('ubicacionInterno'),31),
      ]
    ];
    return pw.Expanded(child:pw.Container(
      decoration:pw.BoxDecoration(border:pw.Border(right:internal?pw.BorderSide.none:const pw.BorderSide(width:.6))),
      child:pw.Column(children:parts)));
  }
  static pw.Widget selection(String title,List<String> options,List<String> chosen)=>
    pw.Container(height:21*s,decoration:pw.BoxDecoration(border:pw.Border.all(width:.65)),
      child:pw.Row(children:[
        pw.Container(width:98*s,alignment:pw.Alignment.centerLeft,padding:const pw.EdgeInsets.only(left:3),
          decoration:const pw.BoxDecoration(border:pw.Border(right:pw.BorderSide(width:.5))),
          child:pw.Text(title,style:txt(10,true))),
        pw.Expanded(child:pw.Row(mainAxisAlignment:pw.MainAxisAlignment.spaceEvenly,
          children:options.map((o)=>pw.Row(mainAxisSize:pw.MainAxisSize.min,children:[
            pw.Text(o,style:txt(8.2)),pw.SizedBox(width:3),
            pw.Container(width:8,height:8,decoration:pw.BoxDecoration(border:pw.Border.all(width:.6)),
              child:pw.Center(child:pw.Text(chosen.contains(o)?'X':'',style:txt(7,true))))
          ])).toList()))
      ]));
  static pw.Widget signature(String heading,List<(String,String)> values)=>pw.Expanded(
    child:pw.Padding(padding:const pw.EdgeInsets.all(5),
      child:pw.Column(crossAxisAlignment:pw.CrossAxisAlignment.stretch,children:[
        pw.Center(child:pw.Text(heading,style:txt(11,true))),pw.SizedBox(height:5),
        ...values.map((pair)=>pw.Container(height:24*s,child:pw.Row(children:[
          pw.SizedBox(width:88*s,child:pw.Text(pair.$1,style:txt(10,true))),
          pw.Expanded(child:pw.Container(alignment:pw.Alignment.bottomCenter,
            decoration:const pw.BoxDecoration(border:pw.Border(bottom:pw.BorderSide(width:.5))),
            child:pw.Text(pair.$2,style:txt(10))))
        ])))
      ])));
  static Future<Uint8List> generate(Salida original)async{
    final d=original.imprimible;
    final logoBytes=await rootBundle.load('assets/report_logo.png');
    final logo=pw.MemoryImage(logoBytes.buffer.asUint8List());
    final doc=pw.Document(compress:true);
    doc.addPage(pw.Page(pageFormat:PdfPageFormat.letter,margin:pw.EdgeInsets.zero,
      build:(context)=>pw.Stack(children:[
        positioned(31,22,754,978,pw.Container(decoration:pw.BoxDecoration(border:pw.Border.all(width:1.5)))),
        positioned(40,36,736,83,pw.Column(children:[
          pw.Image(logo,width:139*s,height:53*s,fit:pw.BoxFit.contain),
          pw.Text('CONDUCE SALIDA HERRAMIENTAS, MATERIALES Y OTROS BIENES',style:txt(11.3,true))])),
        positioned(514,133,256,42,pw.Column(children:[
          pw.Row(children:[pw.SizedBox(width:45*s,child:pw.Text('Fecha:',style:txt(11,true))),
            pw.Expanded(child:pw.Container(decoration:const pw.BoxDecoration(border:pw.Border(bottom:pw.BorderSide(width:.6))),
              child:pw.Text(d.fecha,style:txt(11))))]),pw.SizedBox(height:4),
          pw.Row(children:[pw.SizedBox(width:45*s,child:pw.Text('Hora:',style:txt(11,true))),
            pw.Expanded(child:pw.Container(decoration:const pw.BoxDecoration(border:pw.Border(bottom:pw.BorderSide(width:.6))),
              child:pw.Text(d.hora,style:txt(11))))])])),
        positioned(45,192,726,74,pw.Column(mainAxisAlignment:pw.MainAxisAlignment.spaceBetween,children:[
          selection('Localidad:',Salida.localidades,[d.localidad]),
          selection('Tipo salida:',Salida.tipos,[d.tipo]),
          selection('Concepto salida:',Salida.conceptosValidos,d.conceptos),
        ])),
        positioned(45,292,726,417,pw.Container(decoration:pw.BoxDecoration(border:pw.Border.all(width:.7)),
          child:pw.Column(children:[
            pw.Container(height:21*s,alignment:pw.Alignment.center,
              decoration:const pw.BoxDecoration(border:pw.Border(bottom:pw.BorderSide(width:.5))),
              child:pw.Text('DATOS SOLICITUD SALIDA',style:txt(10.5,true))),
            pw.Expanded(child:pw.Row(crossAxisAlignment:pw.CrossAxisAlignment.start,children:[
              sector(d,internal:false),sector(d,internal:true),
            ])),
          ]))),
        positioned(45,734,726,166,pw.Container(decoration:pw.BoxDecoration(border:pw.Border.all(width:.7)),
          child:pw.Row(children:[
            pw.Flexible(flex:59,child:pw.Row(children:[
              signature('Autorizado por:',[
                ('Nombre:',d.campo('autNombre')),('Firma:',d.campo('autFirma')),
                ('Posición:',d.campo('autPosicion')),('Fecha:',d.campo('autFecha'))])])),
            pw.Container(width:.6,color:PdfColors.black),
            pw.Flexible(flex:41,child:pw.Row(children:[signature('Entregado a:',[
              ('Nombre:',d.campo('entNombre')),('Firma:',d.campo('entFirma')),
              ('Posición:',d.campo('entPosicion')),('Placa/ficha:',d.campo('entPlaca')),
              ('Fecha:',d.campo('entFecha'))])]))
          ]))),
        positioned(47,932,724,46,pw.Text('Nota: En caso de que estos artículos no sean utilizados, según concepto salida, deberán ser retornados en su totalidad a la persona quien autorizó la salida.',style:txt(9.2))),
      ])));
    return doc.save();
  }
}
