import 'package:flutter/material.dart';
import '../core/porta_theme.dart';
import '../core/validation.dart';
import '../data/salida_repository.dart';
import '../models/salida.dart';
import '../services/export_service.dart';
import '../widgets/form_widgets.dart';

class EditorScreen extends StatefulWidget {
  final SalidaRepository repo;final Salida? initial;final VoidCallback onSaved;
  const EditorScreen({super.key,required this.repo,this.initial,required this.onSaved});
  @override State<EditorScreen> createState()=>_EditorScreenState();
}
class _EditorScreenState extends State<EditorScreen> {
  late Salida draft; late Map<String,TextEditingController> controllers;
  late TextEditingController materials,date,time;
  bool busy=false;
  @override void initState(){super.initState();draft=widget.initial??Salida.nueva();
    controllers={for(final k in Salida.keys) k:TextEditingController(text:draft.campo(k))};
    materials=TextEditingController(text:draft.materiales);
    date=TextEditingController(text:draft.fecha);time=TextEditingController(text:draft.hora);
  }
  @override void dispose(){for(final c in controllers.values){c.dispose();} materials.dispose();date.dispose();time.dispose();super.dispose();}
  Salida gather()=>draft.copyWith(fecha:date.text.trim(),hora:time.text.trim(),
    materiales:materials.text.trim(),campos:{for(final e in controllers.entries)e.key:e.value.text.trim()});
  Widget field(String key,String label,{int lines=1})=>Padding(padding:const EdgeInsets.only(bottom:10),
    child:TextField(controller:controllers[key],maxLines:lines,decoration:InputDecoration(labelText:label)));
  Future<void> save()async{
    if(busy)return;
    final data=gather();final problems=ValidadorSalida.errores(data);
    if(problems.isNotEmpty){ScaffoldMessenger.of(context).showSnackBar(SnackBar(content:Text(problems.join(' · '))));return;}
    setState(()=>busy=true);
    try{
      final saved=await widget.repo.save(data);
      draft=saved; final message=await ExportService.saveAndSend(saved);
      if(!mounted)return;
      ScaffoldMessenger.of(context).showSnackBar(SnackBar(content:Text(message)));
      widget.onSaved();
    }catch(e){if(mounted)ScaffoldMessenger.of(context).showSnackBar(SnackBar(content:Text('Guardado/exportación: $e')));}
    finally{if(mounted)setState(()=>busy=false);}
  }
  @override Widget build(BuildContext context){
    final type=draft.tipo;
    return Scaffold(appBar:AppBar(title:Text(draft.id.isEmpty?'Nuevo conduce':'Editar conduce')),
      body:ListView(padding:const EdgeInsets.all(14),children:[
        SectionCard(title:'01 · Fecha, hora y localidad',child:Column(crossAxisAlignment:CrossAxisAlignment.stretch,children:[
          Row(children:[Expanded(child:TextField(controller:date,decoration:const InputDecoration(labelText:'Fecha AAAA-MM-DD'))),
            const SizedBox(width:8),Expanded(child:TextField(controller:time,decoration:const InputDecoration(labelText:'Hora HH:MM')))]),
          const SizedBox(height:12),SelectChips(items:Salida.localidades,selected:draft.localidad.isEmpty?[]:[draft.localidad],
            onChanged:(v)=>setState(()=>draft=draft.copyWith(localidad:v.isEmpty?'':v.first))),
        ])),
        SectionCard(title:'02 · Tipo y concepto de salida',child:Column(crossAxisAlignment:CrossAxisAlignment.start,children:[
          SelectChips(items:Salida.tipos,selected:type.isEmpty?[]:[type],
            onChanged:(v)=>setState(()=>draft=draft.copyWith(tipo:v.isEmpty?'':v.first))),
          const SizedBox(height:12),SelectChips(items:Salida.conceptosValidos,multi:true,selected:draft.conceptos,
            onChanged:(v)=>setState(()=>draft=draft.copyWith(conceptos:v))),
        ])),
        SectionCard(title:'03 · Datos de solicitud (${type.isEmpty?'elige tipo':type})',child:Column(children:[
          if(type=='Terceros')...[
            field('empresa','Empresa'),field('rnc','RNC'),field('chofer','Nombre y apellidos chofer'),
            field('cedulaChofer','Cédula chofer'),field('cantidadTerceros','Cantidad'),
            field('disposicionTerceros','Disposición final',lines:2),
          ],
          if(type=='Interno')...[
            field('nombreInterno','Nombre y apellidos'),field('posicionInterno','Posición'),
            field('cantidadInterno','Cantidad'),field('ubicacionInterno','Ubicación servicio rescate'),
            field('disposicionInterno','Disposición final',lines:2),
          ],
          if(type.isEmpty)const Text('Selecciona Interno o Terceros para habilitar los campos.'),
          if(type.isNotEmpty)...[
            TextField(controller:materials,maxLines:5,decoration:const InputDecoration(
              labelText:'Herramientas, materiales o bienes',helperText:'Separar artículos con guiones. Máximo 8 líneas en el PDF.'),
              onChanged:(_)=>setState((){})),
            const SizedBox(height:6),Align(alignment:Alignment.centerRight,child:Text('Estimado: ${ValidadorSalida.lineasEstimadas(materials.text)}/8 líneas',
              style:TextStyle(color:ValidadorSalida.lineasEstimadas(materials.text)>8?Colors.red:PortaColors.forest))),
          ]
        ])),
        SectionCard(title:'04 · Autorización y entrega',child:Column(children:[
          field('autNombre','Autorizado por · Nombre'),field('autPosicion','Posición'),
          field('autFecha','Fecha autorización'),field('autFirma','Firma opcional'),
          const Divider(height:26),field('entNombre','Entregado a · Nombre'),field('entPosicion','Posición'),
          field('entPlaca','Placa vehículo / ficha equipo'),field('entFecha','Fecha entrega'),
          field('entFirma','Firma opcional'),
        ])),
        OutlinedButton.icon(onPressed:()=>ExportService.preview(gather()),icon:const Icon(Icons.picture_as_pdf_outlined),
          label:const Text('Vista previa PDF oficial')),
        const SizedBox(height:12),
        ElevatedButton.icon(onPressed:busy?null:save,icon:const Icon(Icons.send_outlined),
          label:Text(busy?'Procesando...':'Guardar y enviar')),
        const SizedBox(height:32),
      ]),
    );
  }
}
