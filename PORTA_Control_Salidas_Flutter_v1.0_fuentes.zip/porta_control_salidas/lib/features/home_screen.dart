import 'package:flutter/material.dart';
import '../core/porta_theme.dart';
import '../data/salida_repository.dart';
import '../models/salida.dart';
import '../services/export_service.dart';
import '../services/backup_service.dart';
import 'editor_screen.dart';

class HomeScreen extends StatefulWidget {
  final SalidaRepository repo;const HomeScreen({super.key,required this.repo});
  @override State<HomeScreen> createState()=>_HomeScreenState();
}
class _HomeScreenState extends State<HomeScreen>{
  int tab=0;String search='',type='';List<Salida> records=[];List<Auditoria> events=[];
  String from='',to='';bool loading=true;
  @override void initState(){super.initState();refresh();}
  Future<void> refresh()async{
    final r=await widget.repo.query(texto:search,tipo:type,desde:from,hasta:to);
    final a=await widget.repo.auditoria();
    if(mounted)setState((){records=r;events=a;loading=false;});
  }
  void edit([Salida? item])async{
    await Navigator.of(context).push(MaterialPageRoute(builder:(_)=>EditorScreen(repo:widget.repo,
      initial:item,onSaved:(){refresh();Navigator.of(context).pop();})));
    refresh();
  }
  Widget infoTile(Salida s)=>Card(child:ListTile(
    leading:CircleAvatar(backgroundColor:s.tipo=='Terceros'?const Color(0xFFE3EBF3):const Color(0xFFE3EFE7),
      child:Icon(s.tipo=='Terceros'?Icons.local_shipping_outlined:Icons.badge_outlined,color:PortaColors.navy)),
    title:Text(s.nombre,style:const TextStyle(fontWeight:FontWeight.bold)),
    subtitle:Text('${s.fecha}  ${s.hora} · ${s.localidad} · ${s.tipo} · Rev ${s.revision}'),
    trailing:PopupMenuButton<String>(onSelected:(choice){
      if(choice=='edit')edit(s);
      if(choice=='duplicate')edit(s.copyWith(id:'',revision:0,createdAt:'',updatedAt:''));
      if(choice=='pdf')ExportService.preview(s);
    },itemBuilder:(_)=>const[
      PopupMenuItem(value:'edit',child:Text('Recuperar / editar')),
      PopupMenuItem(value:'duplicate',child:Text('Duplicar como nuevo')),
      PopupMenuItem(value:'pdf',child:Text('Ver PDF')),
    ]),onTap:()=>edit(s)));
  Widget home(){
    final today=DateTime.now().toIso8601String().substring(0,10);
    final todayCount=records.where((r)=>r.fecha==today).length;
    return ListView(padding:const EdgeInsets.all(16),children:[
      const Text('Control de salidas',style:TextStyle(fontSize:25,fontWeight:FontWeight.bold,color:PortaColors.charcoal)),
      const Text('Documentos, trazabilidad y consultas locales',style:TextStyle(color:PortaColors.slate)),
      const SizedBox(height:16),Row(children:[
        Expanded(child:_metric('Conduces',records.length,Icons.description_outlined,PortaColors.navy)),
        const SizedBox(width:12),Expanded(child:_metric('Hoy',todayCount,Icons.today_outlined,PortaColors.forest)),
      ]),Row(children:[
        Expanded(child:_metric('Auditorías',events.length,Icons.shield_outlined,PortaColors.brown)),
        const SizedBox(width:12),Expanded(child:_metric('Permanentes',records.length,Icons.archive_outlined,PortaColors.slate)),
      ]),const SizedBox(height:12),
      ElevatedButton.icon(onPressed:()=>edit(),icon:const Icon(Icons.add),label:const Text('Nuevo conduce')),
      const SizedBox(height:18),const Text('Últimos documentos',style:TextStyle(fontWeight:FontWeight.w800,fontSize:18)),
      ...records.take(5).map(infoTile),
      if(records.isEmpty)const Padding(padding:EdgeInsets.all(30),child:Center(child:Text('Aún no hay conduces.'))),
    ]);
  }
  Widget _metric(String label,int count,IconData icon,Color color)=>Card(child:Padding(padding:const EdgeInsets.all(16),
    child:Column(crossAxisAlignment:CrossAxisAlignment.start,children:[Icon(icon,color:color),const SizedBox(height:6),
      Text('$count',style:const TextStyle(fontSize:29,fontWeight:FontWeight.bold)),Text(label,style:const TextStyle(color:PortaColors.slate))])));
  Widget history()=>Column(children:[
    Padding(padding:const EdgeInsets.all(12),child:Column(children:[
      TextField(decoration:const InputDecoration(prefixIcon:Icon(Icons.search),hintText:'Nombre, material, localidad...'),
        onSubmitted:(v){search=v;refresh();}),
      const SizedBox(height:9),
      SingleChildScrollView(scrollDirection:Axis.horizontal,child:Row(children:['Todos','Interno','Terceros'].map((v)=>
        Padding(padding:const EdgeInsets.only(right:6),child:ChoiceChip(label:Text(v),selected:type==(v=='Todos'?'':v),
          onSelected:(_){type=v=='Todos'?'':v;refresh();}))).toList())),
      Row(children:[
        Expanded(child:TextField(decoration:const InputDecoration(labelText:'Desde AAAA-MM-DD'),onSubmitted:(v){from=v;refresh();})),
        const SizedBox(width:8),Expanded(child:TextField(decoration:const InputDecoration(labelText:'Hasta AAAA-MM-DD'),onSubmitted:(v){to=v;refresh();})),
      ])
    ])),
    Expanded(child:ListView(children:[...records.map(infoTile),if(records.isEmpty)const Center(child:Padding(
      padding:EdgeInsets.all(24),child:Text('Sin coincidencias')))]))
  ]);
  Widget audit()=>ListView(padding:const EdgeInsets.all(12),children:[
    const Padding(padding:EdgeInsets.all(8),child:Text('Bitácora de auditoría (solo lectura)',
      style:TextStyle(fontWeight:FontWeight.w800,fontSize:18))),
    ...events.map((e)=>Card(child:ListTile(leading:const Icon(Icons.verified_user_outlined,color:PortaColors.forest),
      title:Text('${e.accion} · ${e.salidaId}'),subtitle:Text('${e.fecha}\n${e.actor}'),isThreeLine:true,
      onTap:()=>showDialog(context:context,builder:(_)=>AlertDialog(title:Text('${e.accion} · ${e.fecha}'),
        content:SingleChildScrollView(child:SelectableText('Antes:\n${e.antes}\n\nDespués:\n${e.despues}')),
        actions:[TextButton(onPressed:()=>Navigator.pop(context),child:const Text('Cerrar'))]))))
  ]);
  @override Widget build(BuildContext context)=>Scaffold(
    appBar:AppBar(title:const Text('PORTA'),actions:[IconButton(tooltip:'Exportar respaldo JSON',
      onPressed:()=>ExportService.backup(widget.repo),icon:const Icon(Icons.backup_outlined)),
      IconButton(tooltip:'Importar respaldo JSON',onPressed:()async{try{final n=await BackupService.importJson(widget.repo);await refresh();if(mounted&&n!=null)ScaffoldMessenger.of(context).showSnackBar(SnackBar(content:Text('$n registros restaurados')));}catch(e){if(mounted)ScaffoldMessenger.of(context).showSnackBar(SnackBar(content:Text('Respaldo inválido: $e')));}},icon:const Icon(Icons.restore_outlined)),
      IconButton(tooltip:'Actualizar',onPressed:refresh,icon:const Icon(Icons.refresh))]),
    body:loading?const Center(child:CircularProgressIndicator()):IndexedStack(index:tab,children:[home(),history(),audit()]),
    floatingActionButton:tab==0?null:FloatingActionButton.extended(onPressed:()=>edit(),
      label:const Text('Nuevo'),icon:const Icon(Icons.add)),
    bottomNavigationBar:NavigationBar(selectedIndex:tab,onDestinationSelected:(i)=>setState(()=>tab=i),
      destinations:const [NavigationDestination(icon:Icon(Icons.dashboard_outlined),label:'Inicio'),
        NavigationDestination(icon:Icon(Icons.list_alt_outlined),label:'Historial'),
        NavigationDestination(icon:Icon(Icons.fact_check_outlined),label:'Auditoría')])
  );
}
