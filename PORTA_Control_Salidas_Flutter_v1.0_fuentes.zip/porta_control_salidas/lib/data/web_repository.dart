import 'dart:convert';
import 'package:sembast/sembast.dart';
import 'package:sembast_web/sembast_web.dart';
import '../models/salida.dart';
import 'salida_repository.dart';

class WebSalidaRepository implements SalidaRepository {
  late Database db;
  final docs=stringMapStoreFactory.store('salidas');
  final logs=intMapStoreFactory.store('auditoria');
  @override Future<void> init() async=>db=await databaseFactoryWeb.openDatabase('porta_salida_web_v1');
  @override Future<Salida> save(Salida s,{String actor='Dispositivo local'})async{
    late Salida saved;
    await db.transaction((tx)async{
      final old=s.id.isEmpty?null:await docs.record(s.id).get(tx);
      final now=DateTime.now().toUtc().toIso8601String();
      final id=s.id.isEmpty?'PORTA-${DateTime.now().microsecondsSinceEpoch}':s.id;
      saved=s.copyWith(id:id,createdAt:old==null?now:'${old['createdAt']}',
        updatedAt:now,revision:old==null?1:((old['revision'] as num).toInt()+1)).imprimible;
      await docs.record(id).put(tx,saved.toJson());
      await logs.add(tx,{'salida_id':id,'accion':old==null?'CREAR':'MODIFICAR',
        'fecha':now,'antes':old==null?'':jsonEncode(old),'despues':saved.encode(),'actor':actor});
    });return saved;
  }
  @override Future<List<Salida>> query({String texto='',String? tipo,String? desde,String? hasta})async{
    final snapshots=await docs.find(db,finder:Finder(sortOrders:[SortOrder('createdAt',false)]));
    return snapshots.map((e)=>Salida.fromJson(e.value)).where((s)=>
      (tipo==null||tipo.isEmpty||s.tipo==tipo) &&
      (desde==null||desde.isEmpty||s.fecha.compareTo(desde)>=0)&&
      (hasta==null||hasta.isEmpty||s.fecha.compareTo(hasta)<=0)&&
      (texto.isEmpty||s.encode().toLowerCase().contains(texto.toLowerCase()))).toList();
  }
  @override Future<List<Auditoria>> auditoria({String? salidaId})async{
    final records=await logs.find(db,finder:Finder(sortOrders:[SortOrder(Field.key,false)]));
    return records.where((s)=>salidaId==null||s.value['salida_id']==salidaId).map((s)=>
      Auditoria(s.key,'${s.value['salida_id']}','${s.value['accion']}','${s.value['fecha']}',
        '${s.value['antes']}','${s.value['despues']}','${s.value['actor']}')).toList();
  }
  @override Future<String> backup()async=>jsonEncode({'schema':1,'salidas':(await query()).map((s)=>s.toJson()).toList()});
  @override Future<int> restore(String value,{String actor='Restauración'})async{
    final decoded=jsonDecode(value) as Map<String,dynamic>;
    if(decoded['schema']!=1||decoded['salidas'] is! List)throw const FormatException('Respaldo incompatible');
    var inserted=0;
    for(final item in decoded['salidas'] as List){
      final s=Salida.fromJson(Map<String,dynamic>.from(item as Map));
      if(await docs.record(s.id).get(db)==null){await save(s.copyWith(revision:0),actor:actor);inserted++;}
    }return inserted;
  }
}
