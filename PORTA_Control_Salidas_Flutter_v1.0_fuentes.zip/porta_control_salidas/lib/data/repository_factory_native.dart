import 'salida_repository.dart';
import 'sqlite_repository.dart';
SalidaRepository createRepository()=>SqliteSalidaRepository();
