import 'salida_repository.dart';
import 'web_repository.dart';
SalidaRepository createRepository()=>WebSalidaRepository();
