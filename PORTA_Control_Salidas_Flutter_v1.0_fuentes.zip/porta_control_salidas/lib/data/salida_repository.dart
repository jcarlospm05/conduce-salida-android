import '../models/salida.dart';
abstract class SalidaRepository {
  Future<void> init();
  Future<Salida> save(Salida data,{String actor='Dispositivo local'});
  Future<List<Salida>> query({String texto='',String? tipo,String? desde,String? hasta});
  Future<List<Auditoria>> auditoria({String? salidaId});
  Future<String> backup();
  Future<int> restore(String json,{String actor='Restauración'});
}
