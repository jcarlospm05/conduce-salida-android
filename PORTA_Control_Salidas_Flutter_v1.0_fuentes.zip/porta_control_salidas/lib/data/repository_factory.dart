import 'salida_repository.dart';
import 'repository_factory_native.dart' if (dart.library.js_interop) 'repository_factory_web.dart' as platform;
SalidaRepository newRepository()=>platform.createRepository();
