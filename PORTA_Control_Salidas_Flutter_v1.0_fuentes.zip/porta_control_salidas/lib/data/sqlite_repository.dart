import 'dart:convert';
import 'package:sqflite/sqflite.dart';
import 'package:path/path.dart' as path;
import 'package:crypto/crypto.dart';
import '../models/salida.dart';
import 'salida_repository.dart';

class SqliteSalidaRepository implements SalidaRepository {
  late Database db;
  @override Future<void> init() async {
    db=await openDatabase(path.join(await getDatabasesPath(),'porta_salida_v1.db'),version:1,
      onConfigure:(d)async=>d.execute('PRAGMA foreign_keys=ON'),
      onCreate:(d,v)async{
        await d.execute('CREATE TABLE salidas(id TEXT PRIMARY KEY,fecha TEXT NOT NULL,hora TEXT,localidad TEXT,tipo TEXT,persona TEXT,materiales TEXT,contenido TEXT NOT NULL,created_at TEXT NOT NULL,updated_at TEXT NOT NULL,revision INTEGER NOT NULL)');
        await d.execute('CREATE INDEX ix_salidas_fecha ON salidas(fecha)');
        await d.execute('CREATE INDEX ix_salidas_tipo ON salidas(tipo)');
        await d.execute('CREATE INDEX ix_salidas_persona ON salidas(persona)');
        await d.execute('CREATE TABLE auditoria(id INTEGER PRIMARY KEY AUTOINCREMENT,salida_id TEXT NOT NULL,accion TEXT NOT NULL,fecha TEXT NOT NULL,antes TEXT NOT NULL,despues TEXT NOT NULL,actor TEXT NOT NULL,hash TEXT NOT NULL)');
        await d.execute('CREATE INDEX ix_auditoria_salida ON auditoria(salida_id)');
        await d.execute("CREATE TRIGGER audit_no_update BEFORE UPDATE ON auditoria BEGIN SELECT RAISE(ABORT,'Auditoria inmutable'); END");
        await d.execute("CREATE TRIGGER audit_no_delete BEFORE DELETE ON auditoria BEGIN SELECT RAISE(ABORT,'Auditoria inmutable'); END");
        await d.execute("CREATE TRIGGER salida_no_delete BEFORE DELETE ON salidas BEGIN SELECT RAISE(ABORT,'No se permite eliminar historicos'); END");
      });
  }
  @override Future<Salida> save(Salida input,{String actor='Dispositivo local'}) async {
    late Salida saved;
    await db.transaction((tx)async{
      final existing=input.id.isEmpty? <Map<String,Object?>>[]:await tx.query('salidas',where:'id=?',whereArgs:[input.id]);
      final previous=existing.isEmpty?'':existing.first['contenido'] as String;
      final now=DateTime.now().toUtc().toIso8601String();
      final id=input.id.isEmpty? 'PORTA-${DateTime.now().microsecondsSinceEpoch}' : input.id;
      saved=input.copyWith(id:id,createdAt:existing.isEmpty?now:existing.first['created_at'] as String,
        updatedAt:now,revision:existing.isEmpty?1:(existing.first['revision'] as int)+1).imprimible;
      final json=saved.encode();
      await tx.insert('salidas',{'id':id,'fecha':saved.fecha,'hora':saved.hora,'localidad':saved.localidad,
        'tipo':saved.tipo,'persona':saved.persona,'materiales':saved.materiales,'contenido':json,
        'created_at':saved.createdAt,'updated_at':now,'revision':saved.revision},conflictAlgorithm:ConflictAlgorithm.replace);
      final hash=sha256.convert(utf8.encode('$id:$previous:$json')).toString();
      await tx.insert('auditoria',{'salida_id':id,'accion':existing.isEmpty?'CREAR':'MODIFICAR',
        'fecha':now,'antes':previous,'despues':json,'actor':actor,'hash':hash});
    });
    return saved;
  }
  @override Future<List<Salida>> query({String texto='',String? tipo,String? desde,String? hasta})async{
    final cond=<String>[],args=<Object?>[];
    if(texto.trim().isNotEmpty){cond.add('(lower(contenido) LIKE ? OR lower(persona) LIKE ?)');args.addAll(List.filled(2,'%${texto.toLowerCase()}%'));}
    if(tipo!=null&&tipo.isNotEmpty){cond.add('tipo=?');args.add(tipo);}
    if(desde!=null&&desde.isNotEmpty){cond.add('fecha>=?');args.add(desde);}
    if(hasta!=null&&hasta.isNotEmpty){cond.add('fecha<=?');args.add(hasta);}
    final rows=await db.query('salidas',where:cond.isEmpty?null:cond.join(' AND '),whereArgs:args,orderBy:'created_at DESC');
    return rows.map((r)=>Salida.fromJson(jsonDecode(r['contenido'] as String))).toList();
  }
  @override Future<List<Auditoria>> auditoria({String? salidaId})async{
    final rows=await db.query('auditoria',where:salidaId==null?null:'salida_id=?',whereArgs:salidaId==null?null:[salidaId],orderBy:'id DESC');
    return rows.map((r)=>Auditoria(r['id'] as int,r['salida_id'] as String,r['accion'] as String,
      r['fecha'] as String,r['antes'] as String,r['despues'] as String,r['actor'] as String)).toList();
  }
  @override Future<String> backup()async=>jsonEncode({'schema':1,'exported_at':DateTime.now().toUtc().toIso8601String(),
    'salidas':(await query()).map((s)=>s.toJson()).toList(),
    'auditoria':(await auditoria()).map((a)=>{'id':a.id,'salida_id':a.salidaId,'accion':a.accion,
      'fecha':a.fecha,'antes':a.antes,'despues':a.despues,'actor':a.actor}).toList()});
  @override Future<int> restore(String value,{String actor='Restauración'})async{
    final decoded=jsonDecode(value) as Map<String,dynamic>;
    if(decoded['schema']!=1||decoded['salidas'] is! List)throw const FormatException('Respaldo incompatible');
    var inserted=0;
    for(final item in decoded['salidas'] as List){
      final s=Salida.fromJson(Map<String,dynamic>.from(item as Map));
      final exists=await db.query('salidas',columns:['id'],where:'id=?',whereArgs:[s.id]);
      if(exists.isEmpty){await save(s.copyWith(revision:0),actor:actor);inserted++;}
    }
    return inserted;
  }
}
