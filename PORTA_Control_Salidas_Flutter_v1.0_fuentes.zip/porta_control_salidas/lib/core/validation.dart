import '../models/salida.dart';

class ValidadorSalida {
  static List<String> errores(Salida s) {
    final issues=<String>[];
    if(!RegExp(r'^\d{4}-\d\d-\d\d$').hasMatch(s.fecha))issues.add('Fecha inválida');
    if(!RegExp(r'^\d\d:\d\d$').hasMatch(s.hora))issues.add('Hora inválida');
    if(!Salida.localidades.contains(s.localidad))issues.add('Selecciona una localidad');
    if(!Salida.tipos.contains(s.tipo))issues.add('Selecciona el tipo de salida');
    if(s.conceptos.isEmpty)issues.add('Selecciona un concepto');
    if(s.persona.trim().isEmpty)issues.add('Indica la persona que retira');
    if(s.materiales.trim().isEmpty)issues.add('Agrega materiales o bienes');
    if(lineasEstimadas(s.materiales)>8)issues.add('Los materiales exceden ocho líneas; abrevia el texto');
    return issues;
  }
  // Límite preliminar en pantalla. El generador verifica que el texto quepa en la caja.
  static int lineasEstimadas(String texto) {
    if(texto.trim().isEmpty)return 0;
    return texto.split('\n').fold<int>(0,(a,line)=>a+((line.length/42).ceil().clamp(1,100)));
  }
}
