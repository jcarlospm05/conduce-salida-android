import 'package:flutter/material.dart';
class PortaColors {
  static const navy=Color(0xFF173B61),forest=Color(0xFF245649),charcoal=Color(0xFF202328);
  static const slate=Color(0xFF59636B),brown=Color(0xFF74513A),canvas=Color(0xFFF2F3F2);
}
class PortaTheme {
  static ThemeData get light => ThemeData(
    useMaterial3:true,scaffoldBackgroundColor:PortaColors.canvas,
    colorScheme:ColorScheme.fromSeed(seedColor:PortaColors.navy,primary:PortaColors.navy,secondary:PortaColors.forest),
    appBarTheme:const AppBarTheme(backgroundColor:PortaColors.navy,foregroundColor:Colors.white,centerTitle:false),
    cardTheme:CardThemeData(color:Colors.white,margin:const EdgeInsets.symmetric(vertical:6),
      shape:RoundedRectangleBorder(borderRadius:BorderRadius.circular(18))),
    inputDecorationTheme:InputDecorationTheme(filled:true,fillColor:Colors.white,
      border:OutlineInputBorder(borderRadius:BorderRadius.circular(12)),
      contentPadding:const EdgeInsets.symmetric(horizontal:14,vertical:12)),
    elevatedButtonTheme:ElevatedButtonThemeData(style:ElevatedButton.styleFrom(
      backgroundColor:PortaColors.forest,foregroundColor:Colors.white,
      minimumSize:const Size.fromHeight(52),shape:RoundedRectangleBorder(borderRadius:BorderRadius.circular(14)))));
}
