import 'package:flutter/material.dart';
import 'core/porta_theme.dart';
import 'data/repository_factory.dart';
import 'features/home_screen.dart';

Future<void> main()async{
  WidgetsFlutterBinding.ensureInitialized();
  final repository=newRepository();
  await repository.init();
  runApp(MaterialApp(title:'PORTA - Control de Salidas',debugShowCheckedModeBanner:false,
    theme:PortaTheme.light,home:HomeScreen(repo:repository)));
}
